/*
 * sensor.c
 *
 *  Created on: Mar 17, 2017
 *      Author: Francisco
 */
#include "xil_types.h"
#include "xiic.h"
#include "dmp.h"

volatile u8				TransmitComplete;
volatile u8				ReceiveComplete;
extern XIic		IIC_inst;	// IIC instance

/*****************************************************************/
//	 I2C functions to communicate with MPU-6050 motion sensor.
//		WRITE
//
// Parameters
// slave_addr - Can ignore this, as it already taken care of. Included for portability with DMP code
// reg_addr   - Address of register on MPU-6050
// length 	  -	Number of bytes to write (if more than one, automatically
// writes to registers in subsequent addresses)
// data - array or pointer to data buffer
/****************************************************************************/
int i2c_write(unsigned char slave_addr, unsigned char reg_addr,
      unsigned char length, unsigned char const *data)
{
	int Status;
	unsigned char datap[length+1]; // data plus one byte for Register Address
	datap[0]=reg_addr;
	for (int i=0;i<length;i++)
		datap[i+1] =data[i];

	// flag to sync transmission
	TransmitComplete = 1;

	// Start the IIC device.
	Status = XIic_Start(&IIC_inst);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	IIC_inst.Options = 0x0; // Single start op

	// Send Register address + data.
	Status = XIic_MasterSend(&IIC_inst, datap, length+1);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	// Wait till data is transmitted. SendHandler toggles
	while (TransmitComplete) {}

	// Stop the IIC device.
	Status = XIic_Stop(&IIC_inst);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	isleep(2e3); // wait this time before writing again to device
	return XST_SUCCESS;
}

/****************************************************************
 * I2C functions to communicate with MPU-6050 motion sensor.
 *  READ
 *  //
// Parameters
// slave_addr - Can ignore this, as it already taken care of. Included for portability with DMP code
// reg_addr   - Address of register on MPU-6050
// length 	  -	Number of bytes to write (if more than one, automatically
// writes to registers in subsequent addresses)
// data - array or pointer to data buffer
/ *******************************************************************/

int i2c_read(unsigned char slave_addr, unsigned char reg_addr,
       unsigned char length, unsigned char *data)
{
	int Status;
	//u32 wait_time=8e3; // 8 ms
	//int BusBusy;

	TransmitComplete = 1; //First write register address
	/*
	 * Start the IIC device.
	 */
	Status = XIic_Start(&IIC_inst);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	// Set Repeated start condition
	IIC_inst.Options = XII_REPEATED_START_OPTION;

	/*
	 * Send the Register Address.
	 */
	Status = XIic_MasterSend(&IIC_inst, &reg_addr, 1);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Wait till data is transmitted.
	 */
	while (TransmitComplete) {}


	ReceiveComplete = 1;
	IIC_inst.Options = 0x0; // Single byte read

	/*
	 * Read the Data.
	 */
	//read 2 at minimum, known I2C controller / Vivado BUG
	if (length==1) {
		u8 tmp[2];
		Status = XIic_MasterRecv(&IIC_inst, tmp, 2);
		if (Status != XST_SUCCESS) {
			return XST_FAILURE;
		}
		data[0]=tmp[0];
	}
	else {
		Status = XIic_MasterRecv(&IIC_inst, data, length);
		if (Status != XST_SUCCESS) {
			return XST_FAILURE;
		}
	}
	/*
	 * Wait till all the data is received.
	 */
	while ((ReceiveComplete) || (XIic_IsIicBusy(&IIC_inst) == TRUE)) {}

	/*
	 * Stop the IIC device.
	 */
	Status = XIic_Stop(&IIC_inst);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}


/*************** INTERRUPT HANDLERS ASSOCIATED WITH IIC *********************/

/****************************************************************************/
/**
/*****************************************************************************/
/**
* This Send handler is called asynchronously from an interrupt context and
* indicates that data in the specified buffer has been sent.
*
* @param	InstancePtr is a pointer to the IIC driver instance for which
* 		the handler is being called for.
*
* @return	None.
*
* @note		None.
*
******************************************************************************/
void SendHandler(XIic *InstancePtr)
{
	TransmitComplete = 0;

}

/*****************************************************************************/
/**
* This Receive handler is called asynchronously from an interrupt context and
* indicates that data in the specified buffer has been Received.
*
* @param	InstancePtr is a pointer to the IIC driver instance for which
* 		the handler is being called for.
*
* @return	None.
*
* @note		None.
*
******************************************************************************/
void ReceiveHandler(XIic *InstancePtr)
{
	ReceiveComplete = 0;

}

/*****************************************************************************/
/**
* This Status handler is called asynchronously from an interrupt
* context and indicates the events that have occurred.
*
* @param	InstancePtr is a pointer to the IIC driver instance for which
*		the handler is being called for.
* @param	Event indicates the condition that has occurred.
*
* @return	None.
*
* @note		None.
*
******************************************************************************/
void StatusHandler(XIic *InstancePtr, int Event)
{
	while(1); // GET HERE IF ERROR
}


