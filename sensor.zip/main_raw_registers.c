
/**
*
* @file motor1.c
*
* @author Francisco Lopez (fjl@pdx.edu)
* @copyright Portland State University, 2014-2015, 2016-2017
*
*
*
******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "platform.h"
#include "xparameters.h"
#include "xstatus.h"
#include "nexys4IO.h"
#include "pmodENC.h"
#include "xgpio.h"
#include "xintc.h"
#include "xtmrctr.h"
#include "PmodOLEDrgb.h"
#include "xtmrctr_l.h"
#include "xbasic_types.h"
#include "xil_types.h"
#include "xil_assert.h"
#include "DC_motor_AXI.h"
#include "xiic.h"
#include "sensor.h"
#include "dmp.h"
/************************** Constant Definitions ****************************/
// Clock frequencies
#define CPU_CLOCK_FREQ_HZ		XPAR_CPU_CORE_CLOCK_FREQ_HZ
#define AXI_CLOCK_FREQ_HZ		XPAR_CPU_M_AXI_DP_FREQ_HZ

// Definition for peripheral IIC controller
#define IIC_DEVICE_ID 			XPAR_IIC_0_DEVICE_ID
#define IIC_BASEADDR			XPAR_IIC_0_BASEADDR

// Definitions for peripheral NEXYS4IO
#define NX4IO_DEVICE_ID		XPAR_NEXYS4IO_0_DEVICE_ID
#define NX4IO_BASEADDR		XPAR_NEXYS4IO_0_S00_AXI_BASEADDR

// Definitions for peripheral PMODOLEDRGB
#define RGBDSPLY_DEVICE_ID		XPAR_PMODOLEDRGB_0_DEVICE_ID
#define RGBDSPLY_GPIO_BASEADDR	XPAR_PMODOLEDRGB_0_AXI_LITE_GPIO_BASEADDR
#define RGBDSPLY_SPI_BASEADDR	XPAR_PMODOLEDRGB_0_AXI_LITE_SPI_BASEADDR
#define RGBDSPLY_SPI_HIGHADDR	XPAR_PMODOLEDRGB_0_AXI_LITE_SPI_HIGHADDR

// Definitions for peripheral PMODENC
#define PMODENC_DEVICE_ID		XPAR_PMODENC_0_DEVICE_ID
#define PMODENC_BASEADDR		XPAR_PMODENC_0_S00_AXI_BASEADDR

// GPIO parameters
#define GPIO_0_DEVICE_ID			XPAR_AXI_GPIO_0_DEVICE_ID
#define GPIO_0_INPUT_0_CHANNEL		1
#define GPIO_0_INPUT2_0_CHANNEL		2
#define GPIO_0_BASEADDR				XPAR_GPIO_0_BASEADDR

// Interrupt Controller parameters
#define INTC_DEVICE_ID			XPAR_INTC_0_DEVICE_ID
#define FIT_INTERRUPT_ID		XPAR_MICROBLAZE_0_AXI_INTC_FIT_TIMER_1_INTERRUPT_INTR // FIT_1 200 Hz, FIT_2 500Hz
#define BTNC_INTERRUPT_ID		XPAR_MICROBLAZE_0_AXI_INTC_XLSLICE_0_DOUT_INTR
#define IIC_INTERRUPT_ID		XPAR_MICROBLAZE_0_AXI_INTC_AXI_IIC_0_IIC2INTC_IRPT_INTR

// Frequency averaging array size
#define ARY_S	10

/**************************** Type Definitions ******************************/

/***************** Macros (Inline Functions) Definitions ********************/

/************************** Variable Definitions ****************************/

/************************** Function Prototypes *****************************/
//u8 mode(u8 a[],int n);
s32 mode(s32 a[],int n);
void usleep(u32 usecs);
void FIT_Handler(void);
void BtnC_Handler(void);

//int do_init_nx4io(u32 BaseAddress);
//int do_init_pmdio(u32 BaseAddress);
//int AXI_Timer_initialize(void);
int do_init();

PmodENC 	pmodENC_inst;				// PmodENC instance ref
PmodOLEDrgb	pmodOLEDrgb_inst;			// PmodOLED instance ref
XGpio		GPIOInst0;					// GPIO instance
XGpio_Config GPIOConfInst0;				// GPIO Config instance
XIntc 		IntrptCtlrInst;				// Interrupt Controller instance
XIic		IIC_inst;					// IIC instance
//XIic 		*IicPtr;					// argument for IIC interrupt handler

// The following variables are shared between non-interrupt processing and
// interrupt processing such that they must be global(and declared volatile)
// These variables are controlled by the FIT timer interrupt handler
// "clkfit" toggles each time the FIT interrupt handler is called so its frequency will
// be 1/2 FIT_CLOCK_FREQ_HZ.  timestamp increments every 1msec and is used in delay_msecs()
volatile u8 			col = 0;
volatile u8				freq;			// measured motor frequency, from Hall sensor
volatile u8				freq_ary[ARY_S];
volatile u8				update_freq;
volatile s32			fit_cnt;
volatile u8				read_fifo;
u16 					sw = 0;
u16  					RotaryCnt;				// read from hardware, range: 0x0 to 0xFFFF
u16						RotaryCntOld=0;			// previous value of RotaryCnt
int						RotaryDelta;			// Delta = RotaryCnt - RotaryCntOld
volatile u16			duty;			// duty cycle motor command
u16						duty_f;
volatile u8				freq_s;			// motor frequency set point
volatile u8 			freq_sa;
u8						avg_freq;
u8 						avg_freq_old;
s16						freq_chg;
u8						oldset;
u8 						oldseta;
u8						oldavg;
s16						err;
s16						err_old;
s16						err_chg;
volatile u8				kp;
volatile u8				ki;
volatile u8				kd;
u8 						k_select;
s32						duty_delta;
s32						p_delta; // proportional correction
s32						i_delta; // integral correction
s32						d_delta; // derivative correction
s32						err_sum;
s32						err_sum_max;
s32						err_sum_min;
u8 						dir;
u16						rpm;
u16						print_data;
//s32 					sum_freq;
//u8					prev_freq;
//u8					prev_avg;
//u8 					final_freq
volatile s32			quat[4];
volatile s32			quat_ary[4][ARY_S];
s32						avg_quat[4];
volatile u8				update_quat;
/************************** MAIN PROGRAM ************************************/
int main()
{
	int sts;
	u16 sw;							// board switches[15:0]
	int  StepIncr=1;				// 1 to 15, increment of Hue, Sat, Val
	u8 RotaryNoNeg=FALSE;

	init_platform();
    sts = do_init();		// initialize the peripherals
    if (XST_SUCCESS != sts)
    {
    	exit(1);
    }

    microblaze_enable_interrupts();		// enable the interrupts
    // Initialize the rotary encoder
	// clear the counter of the encoder if initialized to garbage value on power on
	pmodENC_init(&pmodENC_inst, StepIncr, RotaryNoNeg);
	pmodENC_clear_count(&pmodENC_inst);

	// Set up the display output
	OLEDrgb_Clear(&pmodOLEDrgb_inst);
	OLEDrgb_EnableBackLight(&pmodOLEDrgb_inst, true);

	read_fifo=0;
	freq_s=0;
	freq_sa=0;
	duty_f=0;
	duty=0;
	k_select=0;
	kp=0;
	ki=0;
	kd=0;  // 15-25 kp, >> 8  with FIT 2 (100 MHz)/200,000= 500 Hz  and ARY_S=25
		// 30 -40 kp, >>6 with FIT 2 (100 MHz)/200,000= 500 Hz  and ARY_S=20
	avg_freq=0;
	avg_freq_old=0;
	freq_chg=0;
	duty_delta=0;
	p_delta=0;
	i_delta=0;
	d_delta=0;
	err_sum=0;
	err_sum_max= 500;
	err_sum_min= -err_sum_max;
	dir =0;
	oldset = 0;
	oldseta=0;
	oldavg = 0;
	StepIncr = 1;
	int i_max=1e6; // for wait loop
	//unsigned char data[16]; //data buffer
	for (int i=0;i<4;i++)
		avg_quat[i]=0;
	u8 data[16]; //data buffer

	data[0]=0x80; //reset device
	i2c_write(0,0x6B,1,data);
	usleep(100e3); // wait 100 ms for reset to complete
	//i2c_read(0,0x6B,2,data);
	data[0]=0x00; // wake up
	data[1]=0x00;
	i2c_write(0,0x6B,2,data);// don't read immediately after write?
	//i2c_read(0,0x6B,2,data); // Make sure 0x6B is 0x00 and not 0x40 (sleep mode)

	// test communication by reading a register
	//i2c_read(0,0x75,2,data); // read Who_I_Am ID register expect 0x68
	data[0]=0x03;
	data[1]=0x18;
	data[2]=0x00;
	i2c_write(0,0x1A,3,data); // write to 1A,1B,1C
	data[0]=0x00;
	i2c_write(0,0x23,1,data);
	i2c_write(0,0x38,1,data);
	data[0]=0x04;
	i2c_write(0,0x6A,1,data);
	data[0]=19; // Sampling rate 200 Hz = 1kHz/ (1 + data[0])
	i2c_write(0,0x19,1,data);
	data[0]=0x00;
	//i2c_read(0,0x19,2,data);
	//dmp_load_motion_driver_firmware(); // load DMP firmware image

	//Enable FIFO output accel and gyro
	data[0]=0x77;
	i2c_write(0,0x23,1,data);

//	// Enable 6-axis quat output to FIFO
//	data[0]=0x0A;
//	data[1]=0xA3;
//	data[2]=0x20;
//	data[3]=0x28;
//	data[4]=0x30;
//	data[5]=0x30;
//	i2c_write(0,0x6D,6,data);
	//Reset and Enable FIFO & DMP
	data[0]=0x04;
	i2c_write(0,0x6A,1,data);
	data[0]=0x40;
	i2c_write(0,0x6A,1,data);
//	data[0]=0x08;
//	i2c_write(0,0x6A,1,data);
//	data[0]=0x80;
//	i2c_write(0,0x6A,1,data);
	//data[0]=0x02; // Enable DMP interrupt
	//i2c_write(0,0x38,1,data);
	//XIntc_Enable(&IntrptCtlrInst, FIT_INTERRUPT_ID); // Reads sensor data
	u8 temporas[2];
	u16 fifo_count;
	s16 accel[3];
	s16 gyro[3];
	u8 index;
	s16 accX, accY,accZ;
	s16 gx,gy,gz;

while(1){
	i2c_read(0,0x3B, 2, data);
	accX=(data[0] << 8) | data[1];
	i2c_read(0,0x3D, 2, data);
	accY=(data[0] << 8) | data[1];
	i2c_read(0,0x3F, 2, data);
	accZ=(data[0] << 8) | data[1];
	i2c_read(0,0x43, 2, data);
	gx=(data[0] << 8) | data[1];
	i2c_read(0,0x45, 2, data);
	gy=(data[0] << 8) | data[1];
	i2c_read(0,0x47, 2, data);
	gz=(data[0] << 8) | data[1];
	accX=accX>>8;
	accY=accY>>8;
	accZ=accZ>>8;
	gx=gx>>8;
	gy=gy>>8;
	gz=gz>>8;
	xil_printf("$%d %d %d;" ,accX,accY,accZ);
	//xil_printf("$%d %d %d;" ,gx,gy,gz);
//	xil_printf("accel x= %d \r\n", (char)accX);
//	xil_printf("accel y= %d \r\n", (char)accY);
//	xil_printf("accel z= %d \r\n", (char)accZ);
//	xil_printf("gyro x= %d \r\n", (char)gx);
//	xil_printf("gyro y= %d \r\n", (char)gy);
//	xil_printf("gyro z= %d \r\n", (char)gz);
}


//while (1) {
//	//usleep(200); // wait before reading data!
//
//	i2c_read(0,0x72, 2, temporas);
//	fifo_count = (temporas[0] << 8) | temporas[1];
//	xil_printf("FIFO count = %u \r\n",fifo_count);
//
//	for (int i=0;i<6;i++)
//		i2c_read(0,0x74, 2, &data[2*i]);
//
//	index=0;
//	accel[0] = (data[index+0] << 8) | data[index+1];
//	accel[1] = (data[index+2] << 8) | data[index+3];
//	accel[2] = (data[index+4] << 8) | data[index+5];
//	index=6;
//	gyro[0] = (data[index+0] << 8) | data[index+1];
//	gyro[1] = (data[index+2] << 8) | data[index+3];
//	gyro[2] = (data[index+4] << 8) | data[index+5];
//	xil_printf("accel x= %d \r\n", accel[0]);
//	xil_printf("accel y= %d \r\n", accel[1]);
//	xil_printf("accel z= %d \r\n", accel[2]);
//	xil_printf("gyro x= %d \r\n", gyro[0]);
//	xil_printf("gyro y= %d \r\n", gyro[1]);
//	xil_printf("gyro z= %d \r\n", gyro[2]);
////	xil_printf("data= %d \r\n", data[0]);
////	xil_printf("data= %d \r\n", data[4]);
////	xil_printf("data= %d \r\n", data[8]);
//
//
////	/* Parse DMP packet. */
////	quat[0] = ((s32)data[0] << 24) | ((s32)data[1] << 16) |
////		((s32)data[2] << 8) | data[3];
////	quat[1] = ((s32)data[4] << 24) | ((s32)data[5] << 16) |
////		((s32)data[6] << 8) | data[7];
////	quat[2] = ((s32)data[8] << 24) | ((s32)data[9] << 16) |
////		((s32)data[10] << 8) | data[11];
////	quat[3] = ((s32)data[12] << 24) | ((s32)data[13] << 16) |
////		((s32)data[14] << 8) | data[15];
////	xil_printf("quat[0]= %d \r\n", quat[0]);
////	xil_printf("quat[1]= %d \r\n", quat[1]);
////	xil_printf("quat[2]= %d \r\n", quat[2]);
////	xil_printf("quat[3]= %d \r\n", quat[3]);
//
//	i2c_read(0,0x72, 2, temporas);
//	fifo_count = (temporas[0] << 8) | temporas[1];
//	xil_printf("FIFO count = %u \r\n",fifo_count);
//
//	temporas[0]+=0;
//	//dmp_read_fifo(quat);
//	//xil_printf("quat[0]= %d \r\n", quat[0]);
//	//xil_printf("quat[1]= %d \r\n", quat[1]);
//	//xil_printf("quat[2]= %d \r\n", quat[2]);
//	//xil_printf("quat[3]= %d \r\n", quat[3]);
//}


	while(1)
	{
		if (read_fifo){
			dmp_read_fifo(quat);
//			xil_printf("quat[0]= %d \r\n", quat[0]);
//			xil_printf("quat[1]= %d \r\n", quat[1]);
//			xil_printf("quat[2]= %d \r\n", quat[2]);
//			xil_printf("quat[3]= %d \r\n", quat[3]);
			for (int i=0;i<4;i++)
				quat_ary[i][ fit_cnt ]= quat[i];
			if ( fit_cnt == ARY_S-1 ){
					update_quat=1; // set semaphore for main loop
					fit_cnt = -1;
			}
			fit_cnt++;
			read_fifo=0; // clear semaphore
		}

		if (update_quat) {
			update_quat=0; // clear semaphore
			for (int i=0;i<4;i++)
				avg_quat[i] = mode(&quat_ary[i][0], ARY_S);

			xil_printf("quat[0]= %i \r\n", avg_quat[0]);
			xil_printf("quat[1]= %i \r\n", avg_quat[1]);
			xil_printf("quat[2]= %i \r\n", avg_quat[2]);
			xil_printf("quat[3]= %i \r\n", avg_quat[3]);
		}
	}
//while(1)
//	{
//		sw = NX4IO_getSwitches();
//		print_data = sw & 0x2;
//		StepIncr= (sw & 0x8000) ? 10 : (sw & 0x4000) ? 5 : 1;
//		pmodENC_init(&pmodENC_inst, StepIncr, RotaryNoNeg);
//
//		if ( avg_freq==0 ) {
//			dir = pmodENC_is_switch_on(&pmodENC_inst);
//			DC_MOTOR_AXI_mWriteReg(0x44A40000, 0, dir);
//		}
//
//		// Update frequency set point
//		if ( pmodENC_is_button_pressed(&pmodENC_inst) )
//		{
//			freq_s=freq_sa;
//		}  // end clear the rotary count
//
//		if (NX4IO_isPressed(BTNR))
//			{
//				k_select = (k_select==2) ? 0 : k_select + 1;
//				for (int i=0; i<i_max;i++); // wait loop
//			}
//		else if (NX4IO_isPressed(BTNL))
//			{
//				k_select = (k_select==0) ? 2 : k_select - 1;
//				for (int i=0; i<i_max;i++); // wait loop
//			}
//		else if (NX4IO_isPressed(BTNU))
//			{
//				switch (k_select) {
//					case 0: kp = (kp+StepIncr)>255 ? 255 : kp + StepIncr; // saturate up to 255
//							break;
//					case 1: ki = (ki+StepIncr)>255 ? 255 : ki + StepIncr;
//							break;
//					case 2: kd = (kd+StepIncr)>255 ? 255 : kd + StepIncr;
//				}
//				for (int i=0; i<i_max;i++); // wait loop
//			}
//
//		else if (NX4IO_isPressed(BTND))
//			{
//				switch (k_select) {
//					case 0: kp = (kp-StepIncr)<0 ? 0 : kp - StepIncr; // saturate down to zero
//							break;
//					case 1: ki = (ki-StepIncr)<0 ? 0 : ki - StepIncr;
//							break;
//					case 2: kd = (kd-StepIncr)<0 ? 0 : kd - StepIncr;
//				}
//				for (int i=0; i<i_max;i++); // wait loop
//			}
//
//		// read the new value from the rotary encoder
//		pmodENC_read_count(&pmodENC_inst, &RotaryCnt);
//		RotaryDelta = RotaryCnt - RotaryCntOld;
//		// Following If statement deals with overflow / underflow. The 100 factor added because
//		// fast knob turning can lead to RotaryDelta > StepIncr, i.e. RotaryCntOld didn't update
//		// fast enough to keep with hardware counting rate
//		if ( abs(RotaryDelta) > 100*StepIncr )
//			RotaryDelta = RotaryDelta>0 ? -StepIncr : StepIncr ;
//
//		/////////////////////////////////// P - CONTROL ////////////////////////////////////////////////
//		freq_sa = (freq_sa+RotaryDelta)>150 ? 150 : (freq_sa+RotaryDelta)<0 ? 0 : freq_sa+RotaryDelta; // Saturate 0 to 150 Hz
//		freq_s=freq_sa;
//		//duty_f = (duty_f+RotaryDelta)>4095 ? 4095 : (duty_f+RotaryDelta)<0 ? 0 : duty_f+RotaryDelta; // Saturate 0 to 150 Hz
//
//		if (update_freq) {
//			avg_freq = mode(freq_ary, ARY_S);
//			rpm= avg_freq*60;
//			update_freq=0;  // clear semaphore
//
//			// Error Calculation
//			err = freq_s - avg_freq; // error = target - actual
//
//			// Proportional control
//			p_delta = (kp * err) >> 4;
//
//			// Integral Control
//			err_sum += err;
//			if (err_sum > err_sum_max) err_sum = err_sum_max;
//			else if (err_sum < err_sum_min) err_sum =err_sum_min;
//			i_delta = (err_sum * ki) >> 12;
//
//			// Derivative Control
//			//freq_chg = avg_freq - avg_freq_old;
//			//d_delta = freq_chg*kd >> 4;
//			//avg_freq_old=avg_freq;
//			err_chg = err - err_old;
//			d_delta = err_chg*kd >> 4;
//			err_old=err;
//
//			//Duty Delta with PID Control
//			duty_delta = p_delta + i_delta + d_delta;
//			duty = ( duty + duty_delta)> 4095 ? 4095 : ( duty + duty_delta)< 0 ? 0 : duty + duty_delta; // Saturate 0 to 4095
//			duty = duty < 310 ? 310 : duty;
//
//			//DC_MOTOR_AXI_mWriteReg(0x44A40000, 4, duty_f);
//			DC_MOTOR_AXI_mWriteReg(0x44A40000, 4, duty);
//
//			if (print_data) {
//				xil_printf("%d %d %d %d \r\n",avg_freq, freq_s, kp, err);
//			}
//
//			// OLED Graph
//
//			// Y axis - 0, 0, 0, 126
//			// X axis - 0, 126, 90, 126
//			OLEDrgb_DrawLine(&pmodOLEDrgb_inst, 0,0,0,126,255);		// y axis
//			OLEDrgb_DrawLine(&pmodOLEDrgb_inst, 0,126,90,126,255);  // x axis
//
//			if(col > 90){
//				OLEDrgb_Clear(&pmodOLEDrgb_inst);
//				col = 0;
//				OLEDrgb_DrawLine(&pmodOLEDrgb_inst, 0,0,0,126,255);		// y axis
//				OLEDrgb_DrawLine(&pmodOLEDrgb_inst, 0,126,90,126,255);  // x axis
//			}
//
//			if(RotaryCnt !=  RotaryCntOld){
//				col++;
//			}
//
//
//			col = col + 1;
//
//			//c1, r1, c2, r2
//			// oldset
//			// oldavg
//			OLEDrgb_DrawLine(&pmodOLEDrgb_inst, col,((62-oldset/2) < 5) ? 0 : 62-oldset/2,col+1,((62-freq_s/2) < 5) ? 0 : 62-freq_s/2,OLEDrgb_BuildHSV(128, 255, 255));
//			OLEDrgb_DrawLine(&pmodOLEDrgb_inst, col,((62-oldavg/2) < 5) ? 0 : 62-oldavg/2,col+1,((62-avg_freq/2) < 5) ? 0 : 62-avg_freq/2,OLEDrgb_BuildHSV(80, 255, 255));
//			OLEDrgb_SetCursor(&pmodOLEDrgb_inst, 10, 0);
//			OLEDrgb_PutString(&pmodOLEDrgb_inst, "Hz");
//			if(oldseta != freq_sa){
//				OLEDrgb_SetCursor(&pmodOLEDrgb_inst, 7, 0);
//				OLEDrgb_PutString(&pmodOLEDrgb_inst, "   ");
//			}
//			else{
//				OLEDrgb_SetCursor(&pmodOLEDrgb_inst, 7, 0);
//				PMDIO_putnum(&pmodOLEDrgb_inst, freq_sa, 10, 3);
//			}
//
//			oldavg = avg_freq;
//			oldset = freq_s;
//			oldseta = freq_sa;
//
//		}
//
//
//		RotaryCntOld = RotaryCnt;
//
//		char buf[10]; 			// temp array for bin2bcd conversion
//		char cc_hi[4]; 			// character codes for 4 digits in the SSEGHI bank
//		char cc_lo[4];			// character codes for 4 digits in the SSEGLO bank
//
//		switch (k_select)
//		{
//			case 0: bin2bcd(kp,buf);
//					buf[6]=10; //  'A' for proportinal
//					break;
//			case 1: bin2bcd(ki,buf);
//					buf[6]=27; //  'I' for integral
//					break;
//			case 2: bin2bcd(kd,buf);
//					buf[6]=13; // 'D' for derivative
//		}
//		//bin2bcd(duty_f,buf);
//		cc_hi[3]=buf[6];
//		cc_hi[2]=buf[7];
//		cc_hi[1]=buf[8];
//		cc_hi[0]=buf[9];
//
//		bin2bcd(avg_freq,buf);
//		cc_lo[3]=buf[6];
//		cc_lo[2]=buf[7];
//		cc_lo[1]=buf[8];
//		cc_lo[0]=buf[9];
//
//		// display the measured duty cycles on seven segment display
//		NX410_SSEG_setAllDigits(SSEGHI, cc_hi[3], cc_hi[2], cc_hi[1], cc_hi[0], 0);
//		NX410_SSEG_setAllDigits(SSEGLO, cc_lo[3], cc_lo[2], cc_lo[1], cc_lo[0], 0);
//	}
}

/**
 * Function Name: do_init()
 *
 * Return: XST_FAILURE or XST_SUCCESS
 *
 * Description: Initialize the AXI timer, gpio, interrupt, FIT timer, Encoder,
 * 				OLED display
 */
int do_init()
{
	int status;

	// initialize IIC controller
	status =  XIic_Initialize(&IIC_inst, IIC_DEVICE_ID );
	if (status == XST_FAILURE)
		{
			exit(1);
		}
	// Set IIC the Transmit, Receive and Status handlers.

		XIic_SetSendHandler(&IIC_inst, &IIC_inst,
					(XIic_Handler) SendHandler);
		XIic_SetRecvHandler(&IIC_inst, &IIC_inst,
					(XIic_Handler) ReceiveHandler);
		XIic_SetStatusHandler(&IIC_inst, &IIC_inst,
					  (XIic_StatusHandler) StatusHandler);

//	// Start the IIC controller device
//	status = XIic_Start(&IIC_inst);
//	if (status != XST_SUCCESS)
//			{
//				exit(1);
//			}
	// Set the address of slave device in I2C bus (MPU-6050 sensor)
	status = XIic_SetAddress(&IIC_inst, XII_ADDR_TO_SEND_TYPE , 0x68);
	if (status != XST_SUCCESS)
				{
					exit(1);
				}

	// initialize the Nexys4 driver and (some of)the devices
	status = (uint32_t) NX4IO_initialize(NX4IO_BASEADDR);
	if (status == XST_FAILURE)
	{
		exit(1);
	}
	NX4IO_setLEDs(0x0000);
	// initialize the PMod544IO driver and the PmodENC and PmodCLP
	status = pmodENC_initialize(&pmodENC_inst, PMODENC_BASEADDR);
	if (status == XST_FAILURE)
	{
		exit(1);
	}

	// initialize the GPIO instances
	// GPIO0 channel 1 is an 8-bit input port.
	// GPIO0 channel 2 is an 24-bit input port.
	status = XGpio_Initialize(&GPIOInst0, GPIO_0_DEVICE_ID);
	if (status != XST_SUCCESS)
	{
		return XST_FAILURE;
	}
	/*status = XGpio_CfgInitialize(&GPIOInst0,&GPIOConfInst0, GPIO_0_BASEADDR );
	if (status != XST_SUCCESS)
	{
		return XST_FAILURE;
	}*/
	XGpio_SetDataDirection(&GPIOInst0, GPIO_0_INPUT_0_CHANNEL, 0xFF);
	XGpio_SetDataDirection(&GPIOInst0, GPIO_0_INPUT2_0_CHANNEL, 0xFF);

	// Initialize the AXI Timer
	status = AXI_Timer_initialize();
	if (status != XST_SUCCESS)
	{
		return XST_FAILURE;
	}

	// set all of the display digits to blanks and turn off
	// the decimal points using the "raw" set functions.
	// These registers are formatted according to the spec
	// and should remain unchanged when written to Nexys4IO...
	// something else to check w/ the debugger when we bring the
	// drivers up for the first time
	NX4IO_SSEG_setSSEG_DATA(SSEGHI, 0x0058E30E);
	NX4IO_SSEG_setSSEG_DATA(SSEGLO, 0x00144116);

	// Initialize the OLED display
	OLEDrgb_begin(&pmodOLEDrgb_inst, RGBDSPLY_GPIO_BASEADDR, RGBDSPLY_SPI_BASEADDR);

	// initialize the interrupt controller
	status = XIntc_Initialize(&IntrptCtlrInst, INTC_DEVICE_ID);
	if (status != XST_SUCCESS)
	{
	   return XST_FAILURE;
	}

	// connect the fixed interval timer (FIT) handler to the interrupt
	status = XIntc_Connect(&IntrptCtlrInst, FIT_INTERRUPT_ID,
						   (XInterruptHandler)FIT_Handler,
						   (void *)0);
	if (status != XST_SUCCESS)
	{
		return XST_FAILURE;

	}

	// connect the Center Button (BTNC) handler to the interrupt
	status = XIntc_Connect(&IntrptCtlrInst, BTNC_INTERRUPT_ID,
						   (XInterruptHandler)BtnC_Handler,
						   (void *)0);
	if (status != XST_SUCCESS)
	{
		return XST_FAILURE;

	}
	// Connect the IIC controller interrupt handler (int director)
	status = XIntc_Connect(&IntrptCtlrInst, IIC_INTERRUPT_ID,
			(XInterruptHandler)XIic_InterruptHandler, &IIC_inst);
	if (status != XST_SUCCESS)
	{
		return XST_FAILURE;
	}

	// start the interrupt controller such that interrupts are enabled for
	// all devices that cause interrupts.
	status = XIntc_Start(&IntrptCtlrInst, XIN_REAL_MODE);
	if (status != XST_SUCCESS)
	{
		return XST_FAILURE;
	}

	// enable individual interrupts
//	XIntc_Enable(&IntrptCtlrInst, FIT_INTERRUPT_ID); // Don't enable until after config MPU6050
	XIntc_Enable(&IntrptCtlrInst, BTNC_INTERRUPT_ID);
	XIntc_Enable(&IntrptCtlrInst, IIC_INTERRUPT_ID);
	return XST_SUCCESS;
}

/*
 * AXI timer initializes it to generate out a 4Khz signal, Which is given to the Nexys4IO module as clock input.
 * DO NOT MODIFY
 */
int AXI_Timer_initialize(void){

	uint32_t status;	// status from Xilinx Lib calls
	//u32		 ctlsts;		// control/status register or mask
   	return XST_SUCCESS;
}

/*********************** HELPER FUNCTIONS ***********************************/

/****************************************************************************/
/**
* insert delay (in microseconds) between instructions.
*
* This function should be in libc but it seems to be missing.  This emulation implements
* a delay loop with (really) approximate timing; not perfect but it gets the job done.
*
* @param	usec is the requested delay in microseconds
*
* @return	*NONE*
*
* @note
* This emulation assumes that the microblaze is running @ 100MHz and takes 15 clocks
* per iteration - this is probably totally bogus but it's a start.
*
*****************************************************************************/

static const u32	DELAY_1US_CONSTANT	= 48;	// constant for 1 microsecond delay

void usleep(u32 usec)
{
	volatile u32 i, j;

	for (i = 0; i < usec; i++)
	{
		for (j = 0; j < DELAY_1US_CONSTANT; j++);
	}
	return;
}


/****************************************************************************/
/**
* initialize the Nexys4 LEDs and seven segment display digits
*
* Initializes the NX4IO driver, turns off all of the LEDs and blanks the seven segment display
*
* @param	BaseAddress is the memory mapped address of the start of the Nexys4 registers
*
* @return	XST_SUCCESS if initialization succeeds.  XST_FAILURE otherwise
*
* @note
* The NX4IO_initialize() function calls the NX4IO self-test.  This could
* cause the program to hang if the hardware was not configured properly
*
*****************************************************************************/
int do_init_nx4io(u32 BaseAddress)
{
	int sts;

	// initialize the NX4IO driver
	sts = NX4IO_initialize(BaseAddress);
	if (sts == XST_FAILURE)
		return XST_FAILURE;

	// turn all of the LEDs off using the "raw" set functions
	// functions should mask out the unused bits..something to check w/
	// the debugger when we bring the drivers up for the first time
	NX4IO_setLEDs(0x0000);
	NX4IO_RGBLED_setRGB_DATA(RGB1, 0xFF000000);
	NX4IO_RGBLED_setRGB_DATA(RGB2, 0xFF000000);
	NX4IO_RGBLED_setRGB_CNTRL(RGB1, 0xFFFFFFF0);
	NX4IO_RGBLED_setRGB_CNTRL(RGB2, 0xFFFFFFFC);

	// set all of the display digits to blanks and turn off
	// the decimal points using the "raw" set functions.
	// These registers are formatted according to the spec
	// and should remain unchanged when written to Nexys4IO...
	// something else to check w/ the debugger when we bring the
	// drivers up for the first time
	NX4IO_SSEG_setSSEG_DATA(SSEGHI, 0x0058E30E);
	NX4IO_SSEG_setSSEG_DATA(SSEGLO, 0x00144116);

	return XST_SUCCESS;

}


/*********************** DISPLAY-RELATED FUNCTIONS ***********************************/

/****************************************************************************/
/**
* Converts an integer to ASCII characters
*
* algorithm borrowed from ReactOS system libraries
*
* Converts an integer to ASCII in the specified base.  Assumes string[] is
* long enough to hold the result plus the terminating null
*
* @param 	value is the integer to convert
* @param 	*string is a pointer to a buffer large enough to hold the converted number plus
*  			the terminating null
* @param	radix is the base to use in conversion,
*
* @return  *NONE*
*
* @note
* No size check is done on the return string size.  Make sure you leave room
* for the full string plus the terminating null in string
*****************************************************************************/
void PMDIO_itoa(int32_t value, char *string, int32_t radix)
{
	char tmp[33];
	char *tp = tmp;
	int32_t i;
	uint32_t v;
	int32_t  sign;
	char *sp;

	if (radix > 36 || radix <= 1)
	{
		return;
	}

	sign = ((10 == radix) && (value < 0));
	if (sign)
	{
		v = -value;
	}
	else
	{
		v = (uint32_t) value;
	}

  	while (v || tp == tmp)
  	{
		i = v % radix;
		v = v / radix;
		if (i < 10)
		{
			*tp++ = i+'0';
		}
		else
		{
			*tp++ = i + 'a' - 10;
		}
	}
	sp = string;

	if (sign)
		*sp++ = '-';

	while (tp > tmp)
		*sp++ = *--tp;
	*sp = 0;

  	return;
}


/****************************************************************************/
/**
* Write a 32-bit unsigned hex number to PmodOLEDrgb in Hex
*
* Writes  32-bit unsigned number to the pmodOLEDrgb display starting at the current
* cursor position.
*
* @param num is the number to display as a hex value
*
* @return  *NONE*
*
* @note
* No size checking is done to make sure the string will fit into a single line,
* or the entire display, for that matter.  Watch your string sizes.
*****************************************************************************/
void PMDIO_puthex(PmodOLEDrgb* InstancePtr, uint32_t num)
{
  char  buf[9];
  int32_t   cnt;
  char  *ptr;
  int32_t  digit;

  ptr = buf;
  for (cnt = 7; cnt >= 0; cnt--) {
    digit = (num >> (cnt * 4)) & 0xF;

    if (digit <= 9)
	{
      *ptr++ = (char) ('0' + digit);
	}
    else
	{
      *ptr++ = (char) ('a' - 10 + digit);
	}
  }

  *ptr = (char) 0;
  OLEDrgb_PutString(InstancePtr,buf);

  return;
}


/****************************************************************************/
/**
* Write a 32-bit number in Radix "radix" to LCD display
*
* Writes a 32-bit number to the LCD display starting at the current
* cursor position. "radix" is the base to output the number in.
*
* @param num is the number to display
*
* @param radix is the radix to display number in
*
* @return *NONE*
*
* @note
* No size checking is done to make sure the string will fit into a single line,
* or the entire display, for that matter.  Watch your string sizes.
*****************************************************************************/
void PMDIO_putnum(PmodOLEDrgb* InstancePtr, int32_t num, int32_t radix, u16 field)
{
  char  buf[16];
  u16	zeroes;

  PMDIO_itoa(num, buf, radix);
  zeroes = field - strlen(buf);
  for (int i=zeroes; i>0; i--)
	  OLEDrgb_PutChar(InstancePtr, '0');
  OLEDrgb_PutString(InstancePtr, buf) ;

  return;
}

/****************************************************************************/
/**
* writes a 16-bit unsigned hex number to the selected display bank
*
* Breaks a 16-bit binary number (u16) into individual digits and displays
* them on the selected seven segment display bank.
*
* The Nexys4 board has two 4-digit seven segment display banks.  SSEGLO
* includes digits 3-0 (rightmost digits).  SSEGHI includes digits 7-4
* (leftmost digits)
*
* @param	bank is used to select which of the SSEG_DATA data registers to write
*
* @param	data is the 16-bit unsigned number that will be displayed in hex
*
*
* @return	XST_SUCCESS if the number was displayed correctly.  XST_FAILURE if the operation
*			failed (i.e. one of the parameters was invalid)
*
* @note		See the NEXYS4IO Datasheet for the character code table and the
*			format of the SSEG_DATA registers
* @note		No checking is done on the bank select. Doesn't write
*			invalid registers.
*
*****************************************************************************/
int myNX4IO_SSEG_putU16Hex(enum _NX4IO_ssegbanks bank, u16 data)
{
	u8 cc[8];		// character codes for each of the nibbles in data
	u8 dp;			// current decimal points.  We don't want to change them

	// convert data to hex and display it on all the selected bank of digits
	bin2hex((u32) data, cc);
	switch (bank)
	{
		case SSEGLO:
			dp = (u8) (NX4IO_SSEG_getSSEG_DATA(SSEGLO)  >> 24);
			NX410_SSEG_setAllDigits(SSEGLO, cc[3], cc[2], cc[1], cc[0], dp);
			break;
		case SSEGHI:
			dp = (u8) (NX4IO_SSEG_getSSEG_DATA(SSEGHI)  >> 24);
			NX410_SSEG_setAllDigits(SSEGHI, cc[3], cc[2], cc[1], cc[0], dp);
			break;
		default:
			// Invalid bank.  Operation failed
			return XST_FAILURE;
	}

	// we made it!!
	return XST_SUCCESS;
}

/**********************************************************/
//		Support function to calculate Mode of an array  //
// Mode defined as value occurring with highest frequency

s32 mode(s32 a[],int n) {
   s32 maxValue = 0;
   int maxCount = 0;
   int i, j;

   for (i = 0; i < n; ++i) {
      int count = 0;

      for (j = 0; j < n; ++j) {
         if (a[j] == a[i])
         ++count;
      }

      if (count > maxCount) {
         maxCount = count;
         maxValue = a[i];
      }
   }
   return maxValue;
}


///**********************************************************/
////		Support function to calculate Mode of an array  //
//// Mode defined as value occurring with highest frequency
//
//u8 mode(u8 a[],int n) {
//   u8 maxValue = 0;
//   int maxCount = 0;
//   int i, j;
//
//   for (i = 0; i < n; ++i) {
//      int count = 0;
//
//      for (j = 0; j < n; ++j) {
//         if (a[j] == a[i])
//         ++count;
//      }
//
//      if (count > maxCount) {
//         maxCount = count;
//         maxValue = a[i];
//      }
//   }
//
//   return maxValue;
//}

/**************************** INTERRUPT HANDLERS ******************************/

/****************************************************************************/
/**
* Center Button Interrupt Handler
*
* Stops the motor turning off PWM signal
*
 *****************************************************************************/

void BtnC_Handler(void)
{

	//xil_printf("Stopping motor... set PWM to zero \r\n ");
	DC_MOTOR_AXI_mWriteReg(0x44A40000, 4, 0);
	freq_s=0;
	freq_sa=0;
	duty=0;
	pmodENC_clear_count(&pmodENC_inst);
	kp = 1;
	ki = 1;
	kd =1;
	for (int i=0; i<1e5; i++); // Give time for motor to turn off completely
	// This wait loop is to bypass the hard limit imposed on min duty=121,
	// by waiting until the motor stops, then even if the duty goes back to 121, motor will not start
}

/*******************************************************************************
* Fixed interval timer interrupt handler
*
* Reads sensor output from FIFO and stores parsed quaternion
*
 *****************************************************************************/
void FIT_Handler(void)
{
	read_fifo=1;
}

//void FIT_Handler(void)
//{
//	//read_fifo=1;
//	dmp_read_fifo(quat);
//	for (int i=0;i<4;i++)
//		quat_ary[i][ fit_cnt ]= quat[i];
//	if ( fit_cnt == ARY_S-1 ){
//			update_quat=1; // set semaphore for main loop
//			fit_cnt = -1;
//	}
//	fit_cnt++;
//}

///*******************************************************************************
//* Fixed interval timer interrupt handler
//*
//* Reads the GPIO port which reads back the hardware generated PWM wave for the RGB Leds
//*
//* @note
//* ECE 544 students - When you implement your software solution for pulse width detection in
//* Project 1 this could be a reasonable place to do that processing.
// *****************************************************************************/
//
//void FIT_Handler(void)
//{
//	freq = DC_MOTOR_AXI_mReadReg(0x44A40000, 8); // measured
//	freq_ary[ fit_cnt ]= freq;
//	if ( fit_cnt == ARY_S-1 ){
//			update_freq=1; // set semaphore for main loop
//			fit_cnt = -1;
//}
//	fit_cnt++;
//}


