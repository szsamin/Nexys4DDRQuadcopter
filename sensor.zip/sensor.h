/*
 * sensor.h
 *
 *  Created on: Mar 17, 2017
 *      Author: Francisco
 */

#ifndef SRC_SENSOR_H_
#define SRC_SENSOR_H_

#include "xiic.h"

int i2c_write(unsigned char slave_addr, unsigned char reg_addr,
      unsigned char length, unsigned char const *data);
int i2c_read(unsigned char slave_addr, unsigned char reg_addr,
      unsigned char length, unsigned char *data);
void SendHandler(XIic *InstancePtr);
void ReceiveHandler(XIic *InstancePtr);
void StatusHandler(XIic *InstancePtr, int Event);

#endif /* SRC_SENSOR_H_ */
